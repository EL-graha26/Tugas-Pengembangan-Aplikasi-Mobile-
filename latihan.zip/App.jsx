import MapView from './components/MapView'
import './App.css'

function App() {
  const onMouseOver = (e) => {
    console.log(e);
    const board = document.getElementById('board');
    const p = document.querySelector('p');
    const { clientX: x, clientY: y } = e;
    board.style.left = `${x}px`;
    board.style.top = `${y}px`;
    p.textContent = `x: ${x}, y: ${y}`;
  }
  return (
    <div className="App">
      <header>
        <h1>WebGIS Bandar Lampung</h1>
      </header>
      <main>
        <div onMouseOver={onMouseOver} id="board" style={{height: '100px', width: '100px', backgroundColor: 'yellow'}}>

        </div>
        <p style={{textAlign: 'left'}}>kosong</p>
        <MapView />
        <p>Selamat datang di aplikasi WebGIS Bandar Lampung!</p>
      </main>
    </div>
  )
}

export default App
