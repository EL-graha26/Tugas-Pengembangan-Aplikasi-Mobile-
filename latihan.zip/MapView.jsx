import { MapContainer,
    TileLayer,
    Marker,
    Popup,
    GeoJSON
} from "react-leaflet";

function MapView() {

    const fasilitas = [
        {
            name: "RSUD Abdul Moeloek",
            type: "Rumah Sakit",
            coordinates: [-5.435536, 105.253685]
        },
        {
            name: "Universitas Lampung",
            type: "Pendidikan",
            coordinates: [-5.436831, 105.252710]
        },
        {
            name: "Mall Boemi Kedaton",
            type: "Perbelanjaan",
            coordinates: [-5.436200, 105.256838]
        }
    ];

    const geoJSONData = {
        "type": "FeatureCollection",
        "features": [
            {
                "type": "Feature",
                "properties": {
                    "jenis": "Taman"
                },
                "geometry": {
                    "type": "Polygon",
                    "coordinates": [
                        [
                            [105.252, -5.436],
                            [105.253, -5.436],
                            [105.253, -5.435],
                            [105.252, -5.435],
                            [105.252, -5.436]
                        ]
                    ]
                }
            }
        ]
    };

    const onEachFeature = (feature, layer) => {
        if (feature.properties && feature.properties.jenis) {
            layer.bindPopup(`
                <div>
                    <h3>${feature.properties.jenis}</h3>
                    <p>type: ${feature.geometry.type}</p>
                    <p>coordinates: ${feature.geometry.coordinates}</p>
                </div>
            `);
        }
    }
    return (
        <MapContainer
            center={[-5.435536, 105.253685]}
            zoom={18}
            style={{ height: "100vh", width: "100%" }}
        >
            <TileLayer
                url="https://tile.openstreetmap.org/{z}/{x}/{y}.png"
                attribution='&copy; 
                    <a href="https://www.openstreetmap.org/copyright">
                        OpenStreetMap
                    </a>
                    contributors'
            />
            {fasilitas.map((row, index) => (
                <Marker
                    key={index}
                    position={row.coordinates}
                >
                    <Popup>
                        <h3>{row.name}</h3>
                        <p>{row.type}</p>
                    </Popup>
                </Marker>
            ))}

            <GeoJSON
                data={geoJSONData}
                style={{
                    color: 'blue',
                    weight: 2,
                    fillColor: 'lightblue',
                    fillOpacity: 0.5
                }}
                onEachFeature={onEachFeature}
            />
        </MapContainer>
    );
}

export default MapView;